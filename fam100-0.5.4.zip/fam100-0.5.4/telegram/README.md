# telegram

Provides a binary to play fam100 game in telegram

Commands:

join - Create or Join a game
score - List top score
