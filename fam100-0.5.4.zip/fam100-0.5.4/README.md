# Fam100

Famm100 is a text game library to play "Family Fued"

Current supported platform:

* CLI
* Telegram

Future platform additions:

* Slack

# Contributors

* Ahmy Yulrizka (yulrizka@gmail.com)
